Requisitos:

Instalar la librería de Pygame

Para correrlo, escribir en la terminal lo siguiente:
python Tetris.py